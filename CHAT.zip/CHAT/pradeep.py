"""
FOOD DELIVERY SUPPORT BRIDGE CHATBOT - ADVANCED UI VERSION
Complete System with Real-Time Person-to-Person Chat
Web-Based UI with Flask + Socket.IO for Live Communication
"""

from flask import Flask, render_template, request, jsonify, session, send_file
from flask_socketio import SocketIO, emit, join_room, leave_room
import os
import json
import base64
import hashlib
from datetime import datetime
from typing import Optional, List, Dict, Any
from pymongo import MongoClient, ASCENDING, DESCENDING
from werkzeug.utils import secure_filename
import secrets

# ==================== FILE HANDLER ====================
class FileHandler:
    MAX_FILE_SIZE = 8 * 1024 * 1024
    ALLOWED_EXTENSIONS = {
        'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'pdf': 'application/pdf',
        'png': 'image/png',
        'jpg': 'image/jpeg',
        'jpeg': 'image/jpeg',
        'gif': 'image/gif',
        'mp4': 'video/mp4',
        'avi': 'video/x-msvideo',
        'mov': 'video/quicktime'
    }
    
    @staticmethod
    def validate_file(file) -> tuple[bool, str]:
        if not file:
            return False, "No file provided"
        
        filename = secure_filename(file.filename)
        ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
        
        if ext not in FileHandler.ALLOWED_EXTENSIONS:
            return False, f"File type '{ext}' not allowed"
        
        file.seek(0, os.SEEK_END)
        size = file.tell()
        file.seek(0)
        
        if size > FileHandler.MAX_FILE_SIZE:
            return False, f"File exceeds 8MB limit ({size/(1024*1024):.2f}MB)"
        
        return True, "Valid"
    
    @staticmethod
    def encode_file(file) -> Optional[Dict[str, Any]]:
        is_valid, msg = FileHandler.validate_file(file)
        if not is_valid:
            return None
        
        filename = secure_filename(file.filename)
        ext = filename.rsplit('.', 1)[1].lower()
        file_data = file.read()
        file_hash = hashlib.sha256(file_data).hexdigest()
        
        return {
            'filename': filename,
            'data': base64.b64encode(file_data).decode('utf-8'),
            'mime_type': FileHandler.ALLOWED_EXTENSIONS[ext],
            'size': len(file_data),
            'hash': file_hash,
            'extension': ext,
            'upload_time': datetime.utcnow()
        }

# ==================== DATABASE MANAGER ====================
class DatabaseManager:
    def __init__(self, connection_string: str = "mongodb://localhost:27017/"):
        self.client = MongoClient(connection_string, serverSelectionTimeoutMS=5000)
        self.db = self.client['food_delivery_support']
        self._initialize_collections()
    
    def _initialize_collections(self):
        collections = {
            'users': [('user_id', ASCENDING)],
            'support_members': [('support_id', ASCENDING)],
            'conversations': [('conversation_id', ASCENDING)],
            'messages': [('conversation_id', ASCENDING), ('timestamp', ASCENDING)],
            'files': [('file_hash', ASCENDING)]
        }
        
        for coll_name, indexes in collections.items():
            if coll_name not in self.db.list_collection_names():
                self.db.create_collection(coll_name)
            for index in indexes:
                self.db[coll_name].create_index([index])

# ==================== MODELS ====================
class User:
    def __init__(self, db, user_id, name, email, phone, user_type='customer'):
        self.db = db
        self.user_id = user_id
        self.name = name
        self.email = email
        self.phone = phone
        self.user_type = user_type
        self.online = False
    
    def save(self):
        user_data = {
            'user_id': self.user_id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'user_type': self.user_type,
            'online': self.online,
            'created_at': datetime.utcnow()
        }
        self.db.db['users'].update_one(
            {'user_id': self.user_id},
            {'$set': user_data},
            upsert=True
        )
        return True
    
    @staticmethod
    def get_by_id(db, user_id):
        return db.db['users'].find_one({'user_id': user_id})
    
    @staticmethod
    def set_online_status(db, user_id, status):
        db.db['users'].update_one(
            {'user_id': user_id},
            {'$set': {'online': status, 'last_seen': datetime.utcnow()}}
        )

class Conversation:
    def __init__(self, db, user_id, support_id=None):
        self.db = db
        self.conversation_id = f"CONV_{user_id}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
        self.user_id = user_id
        self.support_id = support_id
        self.status = 'active'
        self.created_at = datetime.utcnow()
    
    def save(self):
        conv_data = {
            'conversation_id': self.conversation_id,
            'user_id': self.user_id,
            'support_id': self.support_id,
            'status': self.status,
            'created_at': self.created_at,
            'last_updated': datetime.utcnow()
        }
        self.db.db['conversations'].insert_one(conv_data)
        return True
    
    @staticmethod
    def get_by_id(db, conversation_id):
        return db.db['conversations'].find_one({'conversation_id': conversation_id})
    
    @staticmethod
    def get_active_for_user(db, user_id):
        return db.db['conversations'].find_one({
            'user_id': user_id,
            'status': 'active'
        }, sort=[('created_at', DESCENDING)])
    
    @staticmethod
    def get_all_for_support(db, support_id):
        return list(db.db['conversations'].find({
            'support_id': support_id,
            'status': 'active'
        }).sort('last_updated', DESCENDING))

class Message:
    def __init__(self, db, conversation_id, sender_id, sender_type, content, file_data=None):
        self.db = db
        self.conversation_id = conversation_id
        self.sender_id = sender_id
        self.sender_type = sender_type
        self.content = content
        self.file_data = file_data
        self.timestamp = datetime.utcnow()
    
    def save(self):
        msg_data = {
            'conversation_id': self.conversation_id,
            'sender_id': self.sender_id,
            'sender_type': self.sender_type,
            'content': self.content,
            'timestamp': self.timestamp,
            'has_attachment': self.file_data is not None,
            'read': False
        }
        
        result = self.db.db['messages'].insert_one(msg_data)
        
        if self.file_data:
            file_doc = {
                'conversation_id': self.conversation_id,
                'message_id': result.inserted_id,
                **self.file_data
            }
            self.db.db['files'].insert_one(file_doc)
        
        self.db.db['conversations'].update_one(
            {'conversation_id': self.conversation_id},
            {'$set': {'last_updated': self.timestamp}}
        )
        
        return result.inserted_id
    
    @staticmethod
    def get_conversation_messages(db, conversation_id):
        messages = list(db.db['messages'].find({
            'conversation_id': conversation_id
        }).sort('timestamp', ASCENDING))
        
        for msg in messages:
            msg['_id'] = str(msg['_id'])
            msg['timestamp'] = msg['timestamp'].isoformat()
            
            if msg.get('has_attachment'):
                file = db.db['files'].find_one({
                    'conversation_id': conversation_id,
                    'message_id': msg['_id']
                })
                if file:
                    msg['file_info'] = {
                        'filename': file['filename'],
                        'size': file['size'],
                        'type': file['extension'],
                        'data': file['data'][:100] + '...' if len(file['data']) > 100 else file['data']
                    }
        
        return messages

# ==================== FLASK APP ====================
app = Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_hex(16)
app.config['UPLOAD_FOLDER'] = 'uploads'
socketio = SocketIO(app, cors_allowed_origins="*")

# Initialize Database
db_manager = DatabaseManager()

# Store active connections
active_users = {}  # {user_id: socket_id}
support_agents = {}  # {support_id: socket_id}

# ==================== HTML TEMPLATES ====================
HTML_INDEX = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Delivery Support - Login</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            width: 90%;
            max-width: 400px;
        }
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-header h1 {
            color: #667eea;
            font-size: 28px;
            margin-bottom: 10px;
        }
        .login-header p {
            color: #666;
            font-size: 14px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }
        .btn-login {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .btn-login:hover {
            transform: translateY(-2px);
        }
        .user-type-toggle {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .user-type-toggle button {
            flex: 1;
            padding: 10px;
            border: 2px solid #e0e0e0;
            background: white;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .user-type-toggle button.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>🍕 Food Delivery Support</h1>
            <p>Connect with our support team instantly</p>
        </div>
        
        <div class="user-type-toggle">
            <button type="button" class="active" onclick="selectUserType('customer')">Customer</button>
            <button type="button" onclick="selectUserType('support')">Support Agent</button>
        </div>
        
        <form id="loginForm" onsubmit="handleLogin(event)">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" id="name" required placeholder="Enter your name">
            </div>
            
            <div class="form-group">
                <label>Email</label>
                <input type="email" id="email" required placeholder="your@email.com">
            </div>
            
            <div class="form-group">
                <label>Phone</label>
                <input type="tel" id="phone" required placeholder="+1234567890">
            </div>
            
            <input type="hidden" id="userType" value="customer">
            
            <button type="submit" class="btn-login">Start Chat</button>
        </form>
    </div>
    
    <script>
        let currentUserType = 'customer';
        
        function selectUserType(type) {
            currentUserType = type;
            document.getElementById('userType').value = type;
            
            const buttons = document.querySelectorAll('.user-type-toggle button');
            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
        }
        
        function handleLogin(event) {
            event.preventDefault();
            
            const userData = {
                name: document.getElementById('name').value,
                email: document.getElementById('email').value,
                phone: document.getElementById('phone').value,
                userType: document.getElementById('userType').value
            };
            
            fetch('/api/login', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(userData)
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (userData.userType === 'customer') {
                        window.location.href = '/chat';
                    } else {
                        window.location.href = '/support-dashboard';
                    }
                }
            });
        }
    </script>
</body>
</html>'''

HTML_CHAT = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Support Chat</title>
    <script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            height: 100vh;
            overflow: hidden;
        }
        .chat-container {
            display: flex;
            flex-direction: column;
            height: 100vh;
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .chat-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .header-left h2 {
            font-size: 20px;
        }
        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #4ade80;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            background: #f8f9fa;
        }
        .message {
            display: flex;
            margin-bottom: 20px;
            animation: slideIn 0.3s;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .message.sent {
            justify-content: flex-end;
        }
        .message-content {
            max-width: 70%;
            padding: 12px 16px;
            border-radius: 18px;
            position: relative;
        }
        .message.received .message-content {
            background: white;
            border: 1px solid #e0e0e0;
            border-bottom-left-radius: 4px;
        }
        .message.sent .message-content {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-bottom-right-radius: 4px;
        }
        .message-sender {
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 4px;
            opacity: 0.8;
        }
        .message-text {
            line-height: 1.4;
            word-wrap: break-word;
        }
        .message-time {
            font-size: 11px;
            opacity: 0.6;
            margin-top: 4px;
        }
        .file-attachment {
            background: rgba(255,255,255,0.2);
            padding: 8px;
            border-radius: 8px;
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .message.received .file-attachment {
            background: #f0f0f0;
        }
        .chat-input-area {
            padding: 20px;
            background: white;
            border-top: 1px solid #e0e0e0;
        }
        .typing-indicator {
            padding: 10px 20px;
            color: #666;
            font-size: 14px;
            font-style: italic;
            display: none;
        }
        .input-wrapper {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }
        .input-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        #messageInput {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            font-size: 14px;
            resize: none;
            font-family: inherit;
            min-height: 50px;
            max-height: 120px;
        }
        #messageInput:focus {
            outline: none;
            border-color: #667eea;
        }
        .file-input-wrapper {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .btn-attach {
            padding: 10px 16px;
            background: #f0f0f0;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 20px;
            transition: background 0.3s;
        }
        .btn-attach:hover {
            background: #e0e0e0;
        }
        .btn-send {
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: transform 0.2s;
        }
        .btn-send:hover {
            transform: translateY(-2px);
        }
        .file-preview {
            font-size: 12px;
            color: #666;
            padding: 8px;
            background: #f0f0f0;
            border-radius: 8px;
        }
        .system-message {
            text-align: center;
            padding: 10px;
            margin: 10px 0;
            background: #e3f2fd;
            border-radius: 8px;
            font-size: 14px;
            color: #1976d2;
        }
        .emoji-picker {
            position: absolute;
            bottom: 70px;
            right: 20px;
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 12px;
            padding: 15px;
            display: none;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .emoji-picker.show {
            display: block;
        }
        .emoji {
            font-size: 24px;
            cursor: pointer;
            margin: 5px;
            transition: transform 0.2s;
        }
        .emoji:hover {
            transform: scale(1.2);
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-header">
            <div class="header-left">
                <div class="status-indicator"></div>
                <div>
                    <h2>🍕 Support Chat</h2>
                    <small id="supportAgentName">Connecting to support...</small>
                </div>
            </div>
            <button onclick="endChat()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 8px 16px; border-radius: 8px; cursor: pointer;">End Chat</button>
        </div>
        
        <div class="chat-messages" id="chatMessages">
            <div class="system-message">
                Welcome! A support agent will be with you shortly...
            </div>
        </div>
        
        <div class="typing-indicator" id="typingIndicator">
            Support agent is typing...
        </div>
        
        <div class="chat-input-area">
            <div class="input-wrapper">
                <div class="input-container">
                    <textarea id="messageInput" placeholder="Type your message..." onkeypress="handleKeyPress(event)"></textarea>
                    <div class="file-input-wrapper">
                        <input type="file" id="fileInput" style="display: none" onchange="handleFileSelect(event)">
                        <button class="btn-attach" onclick="document.getElementById('fileInput').click()">📎</button>
                        <button class="btn-attach" onclick="toggleEmojiPicker()">😊</button>
                        <span id="filePreview" class="file-preview"></span>
                    </div>
                </div>
                <button class="btn-send" onclick="sendMessage()">Send</button>
            </div>
        </div>
    </div>
    
    <div class="emoji-picker" id="emojiPicker">
        <span class="emoji" onclick="insertEmoji('😊')">😊</span>
        <span class="emoji" onclick="insertEmoji('😃')">😃</span>
        <span class="emoji" onclick="insertEmoji('❤️')">❤️</span>
        <span class="emoji" onclick="insertEmoji('👍')">👍</span>
        <span class="emoji" onclick="insertEmoji('🙏')">🙏</span>
        <span class="emoji" onclick="insertEmoji('😅')">😅</span>
    </div>
    
    <script>
        const socket = io();
        let currentConversationId = null;
        let selectedFile = null;
        
        socket.on('connect', () => {
            console.log('Connected to server');
            socket.emit('user_connected', {user_type: 'customer'});
        });
        
        socket.on('conversation_started', (data) => {
            currentConversationId = data.conversation_id;
            if (data.support_name) {
                document.getElementById('supportAgentName').textContent = 'Chatting with ' + data.support_name;
            }
        });
        
        socket.on('receive_message', (data) => {
            addMessage(data.sender_name, data.content, data.timestamp, 'received', data.file_info);
        });
        
        socket.on('agent_typing', () => {
            document.getElementById('typingIndicator').style.display = 'block';
            setTimeout(() => {
                document.getElementById('typingIndicator').style.display = 'none';
            }, 3000);
        });
        
        socket.on('load_history', (data) => {
            data.messages.forEach(msg => {
                const type = msg.sender_type === 'customer' ? 'sent' : 'received';
                addMessage(msg.sender_id, msg.content, msg.timestamp, type, msg.file_info);
            });
        });
        
        function addMessage(sender, content, timestamp, type, fileInfo = null) {
            const messagesDiv = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message ' + type;
            
            let fileHtml = '';
            if (fileInfo) {
                fileHtml = `<div class="file-attachment">📎 ${fileInfo.filename} (${(fileInfo.size/1024).toFixed(2)}KB)</div>`;
            }
            
            const time = new Date(timestamp).toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit'
            });
            
            messageDiv.innerHTML = `
                <div class="message-content">
                    <div class="message-sender">${sender}</div>
                    <div class="message-text">${content}</div>
                    ${fileHtml}
                    <div class="message-time">${time}</div>
                </div>
            `;
            
            messagesDiv.appendChild(messageDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }
        
        function sendMessage() {
            const input = document.getElementById('messageInput');
            const message = input.value.trim();
            
            if (!message && !selectedFile) return;
            
            const messageData = {
                conversation_id: currentConversationId,
                content: message,
                timestamp: new Date().toISOString()
            };
            
            if (selectedFile) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    messageData.file = {
                        name: selectedFile.name,
                        data: e.target.result.split(',')[1],
                        type: selectedFile.type,
                        size: selectedFile.size
                    };
                    
                    socket.emit('send_message', messageData);
                    addMessage('You', message, new Date().toISOString(), 'sent', {
                        filename: selectedFile.name,
                        size: selectedFile.size
                    });
                    
                    selectedFile = null;
                    document.getElementById('filePreview').textContent = '';
                };
                reader.readAsDataURL(selectedFile);
            } else {
                socket.emit('send_message', messageData);
                addMessage('You', message, new Date().toISOString(), 'sent');
            }
            
            input.value = '';
        }
        
        function handleKeyPress(event) {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                sendMessage();
            }
            
            socket.emit('typing', {conversation_id: currentConversationId});
        }
        
        function handleFileSelect(event) {
            const file = event.target.files[0];
            if (file) {
                if (file.size > 8 * 1024 * 1024) {
                    alert('File size must be less than 8MB');
                    return;
                }
                selectedFile = file;
                document.getElementById('filePreview').textContent = `📎 ${file.name}`;
            }
        }
        
        function toggleEmojiPicker() {
            document.getElementById('emojiPicker').classList.toggle('show');
        }
        
        function insertEmoji(emoji) {
            const input = document.getElementById('messageInput');
            input.value += emoji;
            toggleEmojiPicker();
            input.focus();
        }
        
        function endChat() {
            if (confirm('Are you sure you want to end this chat?')) {
                socket.emit('end_conversation', {conversation_id: currentConversationId});
                window.location.href = '/';
            }
        }
    </script>
</body>
</html>'''

HTML_SUPPORT = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Support Dashboard</title>
    <script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            height: 100vh;
            overflow: hidden;
        }
        .dashboard {
            display: grid;
            grid-template-columns: 300px 1fr;
            height: 100vh;
        }
        .sidebar {
            background: white;
            border-right: 1px solid #e0e0e0;
            display: flex;
            flex-direction: column;
        }
        .sidebar-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .conversation-list {
            flex: 1;
            overflow-y: auto;
        }
        .conversation-item {
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
            cursor: pointer;
            transition: background 0.2s;
        }
        .conversation-item:hover {
            background: #f8f9fa;
        }
        .conversation-item.active {
            background: #e3f2fd;
            border-left: 3px solid #667eea;
        }
        .conversation-item h4 {
            font-size: 14px;
            margin-bottom: 4px;
        }
        .conversation-item p {
            font-size: 12px;
            color: #666;
        }
        .main-chat {
            display: flex;
            flex-direction: column;
            background: white;
        }
        .chat-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
        }
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            background: #f8f9fa;
        }
        .message {
            display: flex;
            margin-bottom: 20px;
            animation: slideIn 0.3s;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .message.received {
            justify-content: flex-start;
        }
        .message.sent {
            justify-content: flex-end;
        }
        .message-content {
            max-width: 70%;
            padding: 12px 16px;
            border-radius: 18px;
        }
        .message.received .message-content {
            background: white;
            border: 1px solid #e0e0e0;
        }
        .message.sent .message-content {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .chat-input {
            padding: 20px;
            background: white;
            border-top: 1px solid #e0e0e0;
        }
        .input-wrapper {
            display: flex;
            gap: 10px;
        }
        #messageInput {
            flex: 1;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            font-size: 14px;
        }
        .btn-send {
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>Support Dashboard</h2>
                <p id="supportName"></p>
            </div>
            <div class="conversation-list" id="conversationList">
                <div style="padding: 20px; text-align: center; color: #999;">
                    No active conversations
                </div>
            </div>
        </div>
        
        <div class="main-chat">
            <div class="chat-header">
                <h3 id="currentCustomer">Select a conversation</h3>
            </div>
            
            <div class="chat-messages" id="chatMessages"></div>
            
            <div class="chat-input">
                <div class="input-wrapper">
                    <input type="text" id="messageInput" placeholder="Type your response...">
                    <button class="btn-send" onclick="sendMessage()">Send</button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        const socket = io();
        let currentConversation = null;
        
        socket.on('connect', () => {
            socket.emit('user_connected', {user_type: 'support'});
        });
        
        socket.on('conversation_assigned', (data) => {
            addConversationToList(data);
        });
        
        socket.on('receive_message', (data) => {
            if (currentConversation === data.conversation_id) {
                addMessage(data.sender_name, data.content, data.timestamp, 'received');
            }
        });
        
        function addConversationToList(conv) {
            const list = document.getElementById('conversationList');
            const item = document.createElement('div');
            item.className = 'conversation-item';
            item.onclick = () => selectConversation(conv.conversation_id, conv.customer_name);
            item.innerHTML = `
                <h4>${conv.customer_name}</h4>
                <p>Active conversation</p>
            `;
            list.innerHTML = '';
            list.appendChild(item);
        }
        
        function selectConversation(convId, customerName) {
            currentConversation = convId;
            document.getElementById('currentCustomer').textContent = 'Chat with ' + customerName;
            socket.emit('join_conversation', {conversation_id: convId});
        }
        
        function addMessage(sender, content, timestamp, type) {
            const messagesDiv = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message ' + type;
            messageDiv.innerHTML = `
                <div class="message-content">
                    <div><strong>${sender}</strong></div>
                    <div>${content}</div>
                    <small>${new Date(timestamp).toLocaleTimeString()}</small>
                </div>
            `;
            messagesDiv.appendChild(messageDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }
        
        function sendMessage() {
            const input = document.getElementById('messageInput');
            const message = input.value.trim();
            if (!message || !currentConversation) return;
            
            socket.emit('send_message', {
                conversation_id: currentConversation,
                content: message,
                timestamp: new Date().toISOString()
            });
            
            addMessage('You', message, new Date().toISOString(), 'sent');
            input.value = '';
        }
    </script>
</body>
</html>'''

# ==================== ROUTES ====================
@app.route('/')
def index():
    return HTML_INDEX

@app.route('/chat')
def chat():
    if 'user_id' not in session:
        return redirect('/')
    return HTML_CHAT

@app.route('/support-dashboard')
def support_dashboard():
    if 'user_id' not in session:
        return redirect('/')
    return HTML_SUPPORT

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    user_id = f"{data['userType'].upper()}_{secrets.token_hex(4)}"
    
    user = User(db_manager, user_id, data['name'], data['email'], data['phone'], data['userType'])
    user.save()
    
    session['user_id'] = user_id
    session['user_type'] = data['userType']
    session['user_name'] = data['name']
    
    return jsonify({'success': True, 'user_id': user_id})

# ==================== SOCKET EVENTS ====================
@socketio.on('connect')
def handle_connect():
    print('Client connected')

@socketio.on('user_connected')
def handle_user_connected(data):
    user_id = session.get('user_id')
    user_type = data.get('user_type')
    
    if user_type == 'customer':
        active_users[user_id] = request.sid
        conv = Conversation.get_active_for_user(db_manager, user_id)
        
        if not conv:
            support = db_manager.db['users'].find_one({'user_type': 'support', 'online': True})
            support_id = support['user_id'] if support else None
            
            new_conv = Conversation(db_manager, user_id, support_id)
            new_conv.save()
            
            join_room(new_conv.conversation_id)
            
            emit('conversation_started', {
                'conversation_id': new_conv.conversation_id,
                'support_name': support['name'] if support else 'Support Team'
            })
            
            if support_id and support_id in support_agents:
                emit('conversation_assigned', {
                    'conversation_id': new_conv.conversation_id,
                    'customer_name': session.get('user_name')
                }, room=support_agents[support_id])
    
    elif user_type == 'support':
        support_agents[user_id] = request.sid
        User.set_online_status(db_manager, user_id, True)

@socketio.on('send_message')
def handle_send_message(data):
    user_id = session.get('user_id')
    user_type = session.get('user_type')
    conversation_id = data['conversation_id']
    
    file_data = None
    if 'file' in data:
        file_info = data['file']
        file_data = {
            'filename': file_info['name'],
            'data': file_info['data'],
            'mime_type': file_info['type'],
            'size': file_info['size'],
            'extension': file_info['name'].split('.')[-1],
            'upload_time': datetime.utcnow()
        }
    
    msg = Message(db_manager, conversation_id, user_id, user_type, data['content'], file_data)
    msg.save()
    
    emit('receive_message', {
        'conversation_id': conversation_id,
        'sender_id': user_id,
        'sender_name': session.get('user_name'),
        'content': data['content'],
        'timestamp': data['timestamp'],
        'file_info': {
            'filename': file_data['filename'],
            'size': file_data['size']
        } if file_data else None
    }, room=conversation_id, include_self=False)

@socketio.on('typing')
def handle_typing(data):
    emit('agent_typing', room=data['conversation_id'], include_self=False)

@socketio.on('join_conversation')
def handle_join_conversation(data):
    join_room(data['conversation_id'])
    messages = Message.get_conversation_messages(db_manager, data['conversation_id'])
    emit('load_history', {'messages': messages})

@socketio.on('disconnect')
def handle_disconnect():
    user_id = session.get('user_id')
    if user_id in active_users:
        del active_users[user_id]
    if user_id in support_agents:
        del support_agents[user_id]
        User.set_online_status(db_manager, user_id, False)

if __name__ == '__main__':
    print("\n" + "="*70)
    print("🍕 FOOD DELIVERY SUPPORT - ADVANCED UI SYSTEM")
    print("="*70)
    print("\n✓ Server starting on http://localhost:5000")
    print("✓ Real-time person-to-person chat enabled")
    print("✓ File upload support (8MB max)")
    print("\nMake sure MongoDB is running on localhost:27017")
    print("="*70 + "\n")
    
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)